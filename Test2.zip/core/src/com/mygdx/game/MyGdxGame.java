package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.TimeUtils;

public class MyGdxGame extends ApplicationAdapter { //public enam
	public static final float SCR_WIDTH= 1280, SCR_HEIGHT = 720;

	SpriteBatch batch;
	BitmapFont font;

	Vector3 touch;

	OrthographicCamera camera;


	Texture menuKapy;
	Texture bttPlay, bttDangerous;
	Texture bcgSakuraKapy;
	Texture texture_kapy_min;

	MyButton buttonPlay, buttonDangerous;

	public typeScreen type;

	boolean GameOver = false;

	long startGame, time;
	long durationGame = 100000;
	int counter = 0;


	Kapy kapy;

	@Override
	public void create () {
		batch = new SpriteBatch();



		menuKapy = new Texture("capybara_menu.png");
		bttPlay = new Texture("img_play.png");
		bttDangerous = new Texture("img_dangerous.png");
		bcgSakuraKapy = new Texture("sakura_kary.png");
		texture_kapy_min = new Texture("Kapy_min.png");

		buttonPlay = new MyButton(110, 318, 211, 57);
		buttonDangerous = new MyButton(120, 220, 123, 39);

		touch = new Vector3();

		camera = new OrthographicCamera();
		camera.setToOrtho(false, SCR_WIDTH, SCR_HEIGHT);

		Gdx.input.setInputProcessor(new MyInputProcessor());

		type = typeScreen.MenuKapy;

		startGame = TimeUtils.millis();

		kapy = new Kapy((int)(SCR_WIDTH), 155, 5, 564, 564);

		generateFont();
	}

	@Override
	public void render () {
		//обработка касаий
		/*if(Gdx.input.isTouched()){
			touch.set(Gdx.input.getX(), Gdx.input.getY(), 0);
			camera.unproject(touch);
			if(buttonPlay.hit(touch.x, touch.y)){
				type = typeScreen.PlayKapy;
				System.out.println("avvsdvd");
			}
	}*/
		//отрисовка:
		batch.setProjectionMatrix(camera.combined);
		batch.begin();
		//меню
		if (type == typeScreen.MenuKapy){
			batch.draw(menuKapy, 0, 0, SCR_WIDTH, SCR_HEIGHT);
			batch.draw(bttPlay, 110, 318, 211, 57);
			batch.draw(bttDangerous, 120, 220, 123, 39);
		}
		//игра капи
		if(type == typeScreen.PlayKapy && !GameOver){
			font.draw(batch, "Count: "+counter, SCR_WIDTH-220, SCR_HEIGHT-10);
			kapy.move();
			batch.draw(bcgSakuraKapy, 0, 0, SCR_WIDTH, SCR_HEIGHT);
			batch.draw(texture_kapy_min, kapy.x, kapy.y);

		}

		batch.end();
	}




	@Override
	public void dispose () {
		batch.dispose();
		menuKapy.dispose();
	}

	void generateFont(){
		FreeTypeFontGenerator generator = new FreeTypeFontGenerator(Gdx.files.internal(""));
		FreeTypeFontGenerator.FreeTypeFontParameter parameter = new FreeTypeFontGenerator.FreeTypeFontParameter();
		parameter.size = 40;
		parameter.borderColor = Color.valueOf("#f266e4");
		font = generator.generateFont(parameter);
		generator.dispose();
	}

	class MyInputProcessor implements InputProcessor {

		@Override
		public boolean keyDown(int keycode) {
			return false;
		}

		@Override
		public boolean keyUp(int keycode) {
			return false;
		}

		@Override
		public boolean keyTyped(char character) {
			return false;
		}

		@Override
		public boolean touchDown(int screenX, int screenY, int pointer, int button) {
			touch.set(screenX, screenY, 0);
			camera.unproject(touch);
			if(buttonPlay.hit(touch.x, touch.y)){
				type = typeScreen.PlayKapy;
			}
			if(GameOver == false && kapy.hit(touch.x, touch.y)){
				counter += 1;
			}
			return false;
		}

		@Override
		public boolean touchUp(int screenX, int screenY, int pointer, int button) {
			return false;
		}

		@Override
		public boolean touchCancelled(int screenX, int screenY, int pointer, int button) {
			return false;
		}

		@Override
		public boolean touchDragged(int screenX, int screenY, int pointer) {
			return false;
		}

		@Override
		public boolean mouseMoved(int screenX, int screenY) {
			return false;
		}

		@Override
		public boolean scrolled(float amountX, float amountY) {
			return false;
		}
	}


	public enum typeScreen {
		MenuKapy,
		PlayKapy,
		SettingKapy
	}
}
