package com.mygdx.game;

public class Kapy {
    int x, y;
    int vx;
    int width, height;

    public Kapy(int x, int y, int vx, int width, int height) {
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.width = width;
        this.height = height;
    }
    void move() {
        x -= vx;
    }

    boolean hit(float tx, float ty) {
        return x<tx & tx<x+width & y<ty & ty<y+height;
    }

}